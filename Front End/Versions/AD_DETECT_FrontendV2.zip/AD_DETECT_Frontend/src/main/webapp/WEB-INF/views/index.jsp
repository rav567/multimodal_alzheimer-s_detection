<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AD Detect Frontend - JSP</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css" />
</head>
<body>
<header class="site-header">
    <div class="header-left">
        <div class="banner-image">
            <img src="${pageContext.request.contextPath}/css/images/brain_white_image_banner1.png" alt="Banner Image" />
        </div>
        <div class="logo">CerebroIQ</div>
    </div>
    <div class="header-right">
        <nav>
            <ul>
                <li>
                    <a href="#">ABOUT</a>
                    <div class="info-box">Alzheimer’s detection using 3D CNNs and a Late Fusion Model.</div>
                </li>
                <li>
                    <a href="#">SERVICES</a>
                    <div class="info-box">Alzheimer’s detection using 3D CNNs and a Late Fusion Model.</div>
                </li>
                <li>
                    <a href="#">TESTIMONIALS</a>
                    <div class="info-box">Alzheimer’s detection using 3D CNNs and a Late Fusion Model.</div>
                </li>
                <li>
                    <a href="#">CONTACT</a>
                    <div class="info-box">Alzheimer’s detection using 3D CNNs and a Late Fusion Model.</div>
                </li>
            </ul>
        </nav>
    </div>
</header>

<section class="top-text">
    <div class="top-box">
        <h1>Bringing Tomorrow’s Diagnostics to Today’s Patients.</h1>
    </div>
</section>

<main class="split-content">
    <div class="left-side">
        <h1>Alzheimer Disease Detection Using 3D CNNs and a Late Fusion Model.</h1>
        <p>
            Welcome to CerebroIQ, a secure and innovative platform for advanced medical diagnostics.
        </p>
    </div>
    <div class="right-side">
        <form class="login-form" action="${pageContext.request.contextPath}/login" method="post">
            <p class="access-info">Login below using the credentials provided upon approval of your access request.</p>
            <h2>Login</h2>
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required />
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required />
            </div>
            <div class="form-group">
                <button type="submit">Login</button>
            </div>
        </form>
    </div>
</main>

<section class="our-work">
    <h2>Our Work</h2>
    <p>Discover our cutting-edge diagnostic solutions and innovative research transforming medical imaging.</p>
</section>

<footer class="site-footer">
    <p>&copy; 2025 CerebroIQ. All Rights Reserved.</p>
</footer>
</body>
</html>
