package com.example.ad_detect_frontend.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.ui.Model;

@Controller
public class HomeController {
    @GetMapping("/")
    public String showIndexPage() {
        return "index";
    }

    @GetMapping("/results")
    public String showResultsPage() {
        return "results";
    }


    @PostMapping("/upload")
    public String handleFileUpload(
            @RequestParam("file") MultipartFile file,
            @RequestParam("patientId") String patientId,
            Model model) {

        if (!file.isEmpty()) {
            String originalFilename = file.getOriginalFilename();
            if (originalFilename != null && !originalFilename.toLowerCase().endsWith(".nii.gz")) {
                model.addAttribute("error", "Only .nii.gz files are allowed");
                return "index";
            }
            model.addAttribute("fileName", originalFilename);
            model.addAttribute("patientId", patientId);

        }

        return "results";
    }
}