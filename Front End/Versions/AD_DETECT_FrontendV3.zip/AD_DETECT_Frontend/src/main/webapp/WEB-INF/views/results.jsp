<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CerebroIQ - Analysis Results</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css" />
</head>
<body>
<header class="header">
    <div class="logo-container">
        <img src="${pageContext.request.contextPath}/css/images/brain_white_image_banner1.png" alt="CerebroIQ Logo" class="logo-image" />
        <div class="logo-text">CerebroIQ</div>
    </div>
    <nav class="nav-menu">
        <ul>
            <li><a href="/">Home</a></li>
            <li><a href="/">About</a></li>
            <li><a href="/">Services</a></li>
            <li><a href="/">Contact Us</a></li>
        </ul>
    </nav>
</header>

<div class="container">
    <div class="upload-container">
        <div class="upload-header">
            <h1 class="upload-title">Analysis Results</h1>
            <p class="upload-subtitle">
                Your scan has been successfully analysed.
            </p>
        </div>

        <div class="results-content">
            <div class="result-item">
                <p><strong>Patient ID:</strong> ${patientId}</p>
            </div>
            <div class="result-item">
                <p><strong>File Analysed:</strong> ${fileName}</p>
            </div>
            <div class="result-item">
                <p><strong>Analysis Date:</strong> ${java.time.LocalDate.now()}</p>
            </div>

            <div class="form-row">
                <a href="/" class="submit-button">Upload Another Scan</a>
            </div>
        </div>
    </div>
</div>

<footer class="footer">
    <p>&copy; 2025 CerebroIQ Medical Diagnostics. All Rights Reserved.</p>
</footer>
</body>
</html>