<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CerebroIQ - MRI Scan Upload</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css" />
</head>
<body>
<header class="header">
    <div class="logo-container">
        <img src="${pageContext.request.contextPath}/css/images/brain_white_image_banner1.png" alt="CerebroIQ Logo" class="logo-image" />
        <div class="logo-text">CerebroIQ</div>
    </div>
    <nav class="nav-menu">
        <ul>
            <li><a href="/">Home</a></li>
            <li><a href="/">About</a></li>
            <li><a href="/">Services</a></li>
            <li><a href="/">Contact Us</a></li>
        </ul>
    </nav>
</header>

<div class="container">
    <div class="upload-container">
        <div class="upload-header">
            <h1 class="upload-title">MRI Scan Upload</h1>
            <p class="upload-subtitle">
                Upload patient's MRI scan for Alzheimer's disease analysis using our advanced diagnostic algorithm.
            </p>
        </div>

        <form class="upload-form" action="${pageContext.request.contextPath}/upload" method="post" enctype="multipart/form-data">
            <div class="form-row">
                <label for="patientId" class="form-label">Patient ID:</label>
                <input type="text" id="patientId" name="patientId" required class="file-input" />
            </div>

            <div class="form-row">
                <label for="file" class="form-label">MRI Scan File:</label>
                <div class="file-input-container">
                    <input type="file" id="file" name="file" required accept=".nii.gz" class="file-input" />
                    <p class="format-note">Accepted format: NIfTI (.nii.gz) only</p>
                </div>
            </div>

            <div class="form-row">
                <button type="submit" class="submit-button">Analyse Scan</button>
            </div>
        </form>
    </div>
</div>

<footer class="footer">
    <p>&copy; 2025 CerebroIQ Medical Diagnostics. All Rights Reserved.</p>
</footer>

<script>
    document.querySelector('.upload-form').addEventListener('submit', function(e) {
        const fileInput = document.getElementById('file');
        const filePath = fileInput.value;
        const allowedExtensions = /(\.nii\.gz)$/i;

        if (!allowedExtensions.exec(filePath)) {
            alert('Please upload a file in .nii.gz format only');
            fileInput.value = '';
            e.preventDefault();
            return false;
        }
    });
</script>
</body>
</html>