package com.example.ad_detect_frontend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdDetectFrontendApplicationTests {

	@Test
	void contextLoads() {
	}

}
