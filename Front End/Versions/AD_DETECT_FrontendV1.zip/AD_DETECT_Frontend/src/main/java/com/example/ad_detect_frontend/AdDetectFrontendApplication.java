package com.example.ad_detect_frontend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdDetectFrontendApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdDetectFrontendApplication.class, args);
	}

}
