package com.example.ad_detect_frontend.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {
    // Load the index page when the user visits the root URL ("/")
    @GetMapping("/")
    public String showIndexPage() {
        return "index";// Returns the view named "index.jsp" or "index.html"
    }

    // Load the results page when the user navigates to "/results"
    @GetMapping("/results")
    public String showResultsPage() {
        return "results";
    }// Returns the view named "results.jsp"

}