package com.example.ad_detect_frontend.controller;

import org.springframework.core.io.ByteArrayResource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import java.time.LocalDate;
import java.util.Map;

@Controller
public class ResultsController {

    // Handle POST request from form submission
    @PostMapping("/analyse")
    public String handleUpload(
            @RequestParam("patientId") String patientId,
            @RequestParam("file") MultipartFile file,
            Model model) {

        // URL of the Flask API that performs prediction
        String flaskUrl = "http://127.0.0.1:5000/predict-file";
        Map<String, Object> responseBody = null;

        try {
            // Set headers to indicate we're sending a file
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.MULTIPART_FORM_DATA);

            // Prepare the file to be sent as part of the request
            MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
            body.add("file", new ByteArrayResource(file.getBytes()) {
                @Override
                public String getFilename() {
                    return file.getOriginalFilename(); // Send the actual file name
                }
            });

            // Wrap body and headers into an HttpEntity
            HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, headers);

            // Send the request to Flask backend
            RestTemplate restTemplate = new RestTemplate();
            ResponseEntity<Map> response = restTemplate.postForEntity(flaskUrl, requestEntity, Map.class);
            responseBody = response.getBody();

            // Pass the result values to the HTML view
            model.addAttribute("prediction", responseBody.get("prediction"));
            model.addAttribute("fileName", responseBody.get("filename"));
            model.addAttribute("patientId", patientId);
            model.addAttribute("analysisDate", LocalDate.now().toString());
            model.addAttribute("confidence", responseBody.get("confidence"));

        } catch (Exception e) {
            // If something goes wrong, show error info in the UI instead of crashing
            model.addAttribute("prediction", "Error: " + e.getMessage());
            model.addAttribute("fileName", file.getOriginalFilename());
            model.addAttribute("patientId", patientId);
            model.addAttribute("analysisDate", LocalDate.now().toString());
            model.addAttribute("confidence", "N/A");// Avoid showing null in UI
        }

        // Show the results page regardless of success or failure
        return "results";
    }
}