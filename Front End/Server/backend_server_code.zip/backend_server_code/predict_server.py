from flask import Flask, request, jsonify
import os
import numpy as np
from joblib import load
from werkzeug.utils import secure_filename
import nibabel as nib
import torch
import torch.nn as nn
import logging

#Set up simple logging for debugging and monitoring
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

#Create the Flask app and configure the upload folder
app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'nii.gz'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

#Only accept NIfTI brain scans with .nii.gz extension
def allowed_file(filename):
    return filename.lower().endswith('.nii.gz')

#Define 3D CNN model architecture (same as training)
class CNN3D(nn.Module):
    def __init__(self, input_channels=1, num_classes=2, dropout_rate=0.5):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv3d(input_channels, 32, 3, padding=1),
            nn.BatchNorm3d(32),
            nn.ReLU(inplace=True),
            nn.MaxPool3d(2),
            nn.Conv3d(32, 64, 3, padding=1),
            nn.BatchNorm3d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool3d(2),
            nn.Conv3d(64, 128, 3, padding=1),
            nn.BatchNorm3d(128),
            nn.ReLU(inplace=True),
            nn.MaxPool3d(2)
        )
        self.avg_pool = nn.AdaptiveAvgPool3d((1, 1, 1))
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(128, 256),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout_rate),
            nn.Linear(256, num_classes)
        )

    def forward(self, x):
        x = self.features(x)
        x = self.avg_pool(x)
        return self.classifier(x)

#Detect whether GPU is available
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
logger.info(f"Using device: {device}")

#Load a trained model (handles different saving formats)
def load_model(path):
    model = CNN3D()
    checkpoint = torch.load(path, map_location=device)
    
    if "model_state_dict" in checkpoint:
        logger.info("Loading full checkpoint")
        model.load_state_dict(checkpoint["model_state_dict"])
    else:
        logger.info("Loading model weights only")
        model.load_state_dict(checkpoint)
    
    model.to(device)
    model.eval()
    return model

#Try loading a fusion model, fallback to simple average if not found
def load_fusion_model():
    try:
        model = load("fusion_model.joblib")
        logger.info("Fusion model loaded successfully")
        return model
    except Exception:
        logger.warning("Fusion model not found, using fallback")

        class SimpleFusion:
            def __init__(self, weights=[0.15, 0.65, 0.2]):
                self.weights = weights
            def predict(self, X):
                scores = np.sum(X, axis=1)
                return (scores > 0.5).astype(int)
            def predict_proba(self, X):
                scores = np.sum(X, axis=1)
                probs = np.zeros((len(scores), 2))
                probs[:, 1] = scores
                probs[:, 0] = 1 - scores
                return probs

        return SimpleFusion()

#Load all trained models
try:
    mri_model = load_model("mri_model.pth")
    pet_model = load_model("pet_model.pth")
    coreg_model = load_model("coreg_model.pth")
    fusion_model = load_fusion_model()
    logger.info("All models loaded successfully")
except Exception as e:
    logger.error(f"Model loading failed: {e}")
    raise

#Prepare a scan for prediction (same steps as during training)
def preprocess_scan(file_path):
    try:
        img = nib.load(file_path)
        data = img.get_fdata()

        #If scan is 4D, take the first timepoint
        if len(data.shape) == 4:
            data = data[:, :, :, 0]
        
        #Handle NaNs safely
        if np.isnan(data).any():
            data = np.nan_to_num(data)

        #Normalise voxel intensities
        if np.std(data) == 0:
            normalized_data = data
        else:
            normalized_data = (data - np.mean(data)) / np.std(data)
        
        tensor = torch.tensor(normalized_data[np.newaxis, np.newaxis, ...], dtype=torch.float32).to(device)
        return tensor
    except Exception as e:
        logger.error(f"Preprocessing failed: {e}")
        raise

#Get AD probability score from a model
def predict_with_model(model, tensor):
    try:
        with torch.no_grad():
            outputs = model(tensor)
            probabilities = torch.nn.functional.softmax(outputs, dim=1)
            return probabilities[0, 1].item()
    except Exception as e:
        logger.error(f"Prediction failed: {e}")
        raise

#Score functions per modality
def compute_mri_score(path): return predict_with_model(mri_model, preprocess_scan(path))
def compute_pet_score(path): return predict_with_model(pet_model, preprocess_scan(path))
def compute_coreg_score(path): return predict_with_model(coreg_model, preprocess_scan(path))

#Main prediction route for uploaded files
@app.route('/predict-file', methods=['POST'])
def predict_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400

    file = request.files['file']
    
    if file.filename == '' or not allowed_file(file.filename):
        return jsonify({'error': 'Invalid file type. Please upload a .nii.gz file'}), 400

    filename = secure_filename(file.filename)
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    file.save(file_path)
    logger.info(f"File uploaded: {file_path}")

    try:
        #Get prediction scores from all 3 models
        mri_score = compute_mri_score(file_path)
        pet_score = compute_pet_score(file_path)
        coreg_score = compute_coreg_score(file_path)

        #Create weighted input for the fusion model
        fused_input = np.array([[mri_score*0.15, pet_score*0.65, coreg_score*0.2]])
        logger.info(f"Fusion input: {fused_input}")

        prediction = fusion_model.predict(fused_input)[0]
        raw_proba = fusion_model.predict_proba(fused_input)[0][1]

        #Apply temperature-scaled sigmoid for smoother confidence
        def calibrate_probability(p, temp=1.5):
            logit = np.log(p / (1 - p)) if 0 < p < 1 else (20 if p >= 1 else -20)
            return 1 / (1 + np.exp(-logit / temp))

        calibrated_proba = calibrate_probability(raw_proba)
        confidence = calibrated_proba * 100 if prediction == 1 else (1 - calibrated_proba) * 100
        confidence = np.clip(confidence, 1.0, 99.0)

        logger.info(f"Prediction: {prediction}, Confidence: {confidence}")

        return jsonify({
            'prediction': "Alzheimer's Disease (AD)" if prediction else "Cognitive Normal (CN)",
            'confidence': float(round(confidence, 2)),
            'raw_confidence': float(round(raw_proba * 100, 2)),
            'mri': float(round(mri_score, 4)),
            'pet': float(round(pet_score, 4)),
            'coreg': float(round(coreg_score, 4)),
            'filename': filename
        })
    
    except Exception as e:
        logger.error(f"Prediction error: {str(e)}", exc_info=True)
        return jsonify({'error': str(e)}), 500
    finally:
        if os.path.exists(file_path):
            os.remove(file_path)
            logger.info(f"Deleted temporary file: {file_path}")

#Simple health check endpoint
@app.route('/test', methods=['GET'])
def test():
    return jsonify({'status': 'API is running', 'models_loaded': True})

#Run the app
if __name__ == '__main__':
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    app.run(host='0.0.0.0', port=5000, debug=True)
