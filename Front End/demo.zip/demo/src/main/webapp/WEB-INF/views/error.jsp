<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Error</title>
</head>
<body>
<h2>Login Failed</h2>
<p style="color:red;">${error}</p>
<a href="${pageContext.request.contextPath}/login">Try Again</a>
</body>
</html>
