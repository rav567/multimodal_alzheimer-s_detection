<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Welcome</title>
</head>
<body>
<h2>Welcome, ${username}!</h2>
<p>You have successfully logged in.</p>
</body>
</html>
